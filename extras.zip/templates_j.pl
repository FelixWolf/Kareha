use strict;

BEGIN { require 'wakautils.pl'; }



#
# Interface strings
#

use constant S_NAVIGATION => '�i�r';
use constant S_RETURN => '�f���ɖ߂�';
use constant S_ENTIRE => '���X��S���ǂ�';
use constant S_LAST50 => '�ŐV���X�T�O';
use constant S_FIRST100 => '���X�P�|�P�O�O';
use constant S_BOARDLOOK => '�f�U�C��';
use constant S_ADMIN => '�Ǘ��l';
use constant S_MANAGE => '�Ǘ��p';
use constant S_REBUILD => '�L���b�V���̍č\�z';
use constant S_ALLTHREADS => '�ߋ����O�͂�����';
use constant S_NAME => '���O�F';
use constant S_EMAIL => 'E-mail:';
use constant S_FORCEDANON => '(�����I�ɖ������ɂȂ�܂�)';
use constant S_CAPTCHA => '����:';
use constant S_TITLE => '�^�C�g���F';
use constant S_NEWTHREAD => '�V�K�X���b�h�쐬';
use constant S_REPLY => '��������';
use constant S_LISTEXPL => '�X���b�h���X�g��';
use constant S_PREVEXPL => '�O�̃X���b�h';
use constant S_NEXTEXPL => '���̃X���b�h';
use constant S_LISTBUTTON => '&#9632;';
use constant S_PREVBUTTON => '&#9650;';
use constant S_NEXTBUTTON => '&#9660;';
use constant S_TRUNC => '�ȗ�����܂����E�E�S�Ă�ǂނɂ�<a href="%s">����</a>�������Ă�������';
use constant S_PERMASAGED => '�A�i�vsage';
use constant S_POSTERNAME => '���O�F';
use constant S_DELETE => '�폜';
use constant S_USERDELETE => '���e�҂��폜���܂����B';
use constant S_MODDELETE => '���ځ[��';
use constant S_PERMASAGETHREAD => '�i�vsage';
use constant S_DELETETHREAD => '�폜';

#
# Error strings
#

use constant S_BADCAPTCHA => '�s���Ȍ��؃R�[�h�����͂���܂���';
use constant S_UNJUST => '�s���ȓ��e�����Ȃ��ŉ�����';
use constant S_NOTEXT => '���������ĉ�����';
use constant S_NOTITLE => '�^�C�g���������Ă�������';
use constant S_NOTALLOWED => '�Ǘ��l�ȊO�͓��e�ł��܂���';
use constant S_TOOLONG => '�{�����������܂����I';
use constant S_TOOMANYLINES => '���s���傷���ł����I';
use constant S_UNUSUAL => '�����ςł�';
use constant S_SPAM => '�X�p���𓊍e���Ȃ��ŉ�����';
use constant S_THREADCOLL => '�N���������ɓ��e���悤�Ƃ��܂����B������x���e���Ă�������';
use constant S_PROXY => 'Error: Proxy detected on port %d.';			# Error message for proxy detection.
use constant S_NOTHREADERR => '�X���b�h������܂���';
use constant S_THREADLOCKED => 'Error: Thread is locked.';				# Error message when a non-existant thread is accessed
use constant S_BADDELPASS => '�Y���L����������Ȃ����p�X���[�h���Ԉ���Ă��܂�';
use constant S_NOTWRITE => '�f�B���N�g���ɏ������݌���������܂���';
use constant S_NOADMIN => 'ADMIN_PASS �͋�ɂł��܂���';
use constant S_NOSECRET => 'SECRET �͋�ɂł��܂���';
use constant S_NOTASK => '�X�N���v�g�G���[�F����������܂���';
use constant S_NOLOG => 'log.txt�ɏ������߂܂���';


#
# Templates
#

use constant GLOBAL_HEAD_INCLUDE => q{

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<title><if $title><var $title> - </if><const TITLE></title>
<meta http-equiv="Content-Type"  content="text/html;charset=<const CHARSET>" />
<link rel="shortcut icon" href="<var $path>favicon.ico" />

<if RSS_FILE>
<link rel="alternate" title="RSS feed" href="<var $path><const RSS_FILE>" type="application/rss+xml" />
</if>

<loop \@stylesheets>
<link rel="<if !$default>alternate </if>stylesheet" type="text/css" href="<var $path><var $filename>" title="<var $title>" />
</loop>

<script type="text/javascript">var style_cookie="<const STYLE_COOKIE>";</script>
<script type="text/javascript" src="<var $path>kareha.js"></script>
</head>
};



use constant GLOBAL_FOOT_INCLUDE => q{

<const include("include/footer.html")>

<div id="footer">
- <a href="<var $path><const RSS_FILE>">RSS feed</a>
+ <a href="http://wakaba.c3.cx/">kareha</a>
+ <a href="http://wakaba.c3.cx/">wakaba</a>
-
</div>
</body></html>
};




use constant MAIN_PAGE_TEMPLATE => compile_template( GLOBAL_HEAD_INCLUDE.q{
<body class="mainpage">

<const include("include/header.html")>

<div id="topbar">

<div id="stylebar">
<strong><const S_BOARDLOOK></strong>
<loop \@stylesheets>
	<a href="javascript:set_stylesheet('<var $title>')"><var $title></a>
</loop>
</div>

<div id="managerbar">
<strong><const S_ADMIN></strong>
<a href="javascript:set_manager()"><const S_MANAGE></a>
<span class="manage" style="display:none;">
<a href="<var $self>?task=rebuild"><const S_REBUILD></a>
</span>
</div>

</div>

<div id="threads">

<h1><const TITLE></h1>

<a name="menu"></a>
<div id="threadlist">
<loop $threads><if $num<=THREADS_LISTED>
	<span class="threadlink">
	<a href="<var $self>/<var $thread>"><var $num>. 
	<if $num<=THREADS_DISPLAYED></a><a href="#<var $num>"></if>
	<var $title> (<var $postcount>)</a>
	</span>
</if></loop>

<strong><a href="<var $path><const HTML_BACKLOG>"><const S_ALLTHREADS></a></strong>

</div>

<form name="threadform" action="<var $self>" method="post">
<input type="hidden" name="task" value="post" />
<input type="hidden" name="password" value="" />
<table><col /><col /><col width="100%" /><tbody><tr valign="top">
	<td><nobr><const S_NAME></nobr></td>
	<td style="white-space:nowrap;"><nobr>
		<if !FORCED_ANON><input type="text" name="name" size="19" /></if>
		<if FORCED_ANON><input type="text" size="19" disabled="disabled" /><input type="hidden" name="name" /></if>
		<const S_EMAIL> <input type="text" name="email" size="19" /></nobr>
	</td>
	<td>
		<if FORCED_ANON><small><const S_FORCEDANON></small></if>
	</td>
</tr><tr>
<if ENABLE_CAPTCHA>
	<td><nobr><const S_CAPTCHA></nobr></td>
	<td><input type="text" name="captcha" size="19" />
	<img class="threadcaptcha" src="captcha.pl?selector=.threadcaptcha" />
	</td><td></td>
</tr><tr>
</if>
	<td><nobr><const S_TITLE></nobr></td>
	<td><input type="text" name="title" style="width:100%" /></td>
	<td><input type="submit" value="<const S_NEWTHREAD>" /></td>
	</tr><tr>
	<td></td>
	<td colspan="2"><textarea name="comment" cols="64" rows="5" onfocus="expand_field()" onblur="shrink_field()"></textarea></td>
</tr></tbody></table>
</form>
<script type="text/javascript">with(document.threadform) {if(!name.value) name.value=get_cookie("name"); if(!email.value) email.value=get_cookie("email"); if(!password.value) password.value=get_password("password"); }</script>

</div>

<const include("include/mid.html")>

<div id="posts">

<loop $threads><if $posts>
	<a name="<var $num>"></a>
	<if $permasage><div class="sagethread"></if>
	<if !$permasage><div class="thread"></if>
	<h2><var $title> <small>(<var $postcount><if $permasage>, permasaged</if>)</small></h2>

	<div class="threadnavigation">
	<a href="#menu" title="<const S_LISTEXPL>"><const S_LISTBUTTON></a>
	<a href="#<var $prev>" title="<const S_PREVEXPL>"><const S_PREVBUTTON></a>
	<a href="#<var $next>" title="<cibst S_NEXTEXPL>"><const S_NEXTBUTTON></a>
	</div>

	<div class="replies">

	<if $omit><div class="firstreply"></if>
	<if !$omit><div class="allreplies"></if>

	<loop $posts>
		<var $reply>

		<if $abbrev>
		<div class="replyabbrev">
		<var sprintf(S_TRUNC,"$self/$thread/$postnum","$self/$thread/")>
		</div>
		</if>

		<if $omit and $first>
		</div><div class="repliesomitted"></div><div class="finalreplies">
		</if>
	</loop>

	</div>
	</div>

	<form name="postform<var $thread>" action="<var $self>" method="post">
	<input type="hidden" name="task" value="post" />
	<input type="hidden" name="thread" value="<var $thread>" />
	<input type="hidden" name="password" value="" />
	<table><tbody><tr valign="top">
		<td><nobr><const S_NAME></nobr></td>
		<td>
			<if !FORCED_ANON><input type="text" name="name" size="19" /></if>
			<if FORCED_ANON><input type="text" size="19" disabled="disabled" /><input type="hidden" name="name" /></if>
			<const S_EMAIL> <input type="text" name="email" size="19" />
			<input type="submit" value="<const S_REPLY>" />
			<if FORCED_ANON><small><const S_FORCEDANON></small></if>
		</td>
	</tr><tr>
	<if ENABLE_CAPTCHA>
		<td><nobr><const S_CAPTCHA></nobr></td>
		<td><input type="text" name="captcha" size="19" />
		<img class="postcaptcha" src="captcha.pl?selector=.postcaptcha" />
		</td>
	</tr><tr>
	</if>
		<td></td>
		<td><textarea name="comment" cols="64" rows="5" onfocus="expand_field(<var $thread>)" onblur="shrink_field(<var $thread>)"></textarea></td>
	</tr><tr>
		<td></td>

		<td><div class="threadlinks">
		<a href="<var $self>/<var $thread>/"><const S_ENTIRE></a>
		<a href="<var $self>/<var $thread>/l50"><const S_LAST50></a>
		<a href="<var $self>/<var $thread>/-100"><const S_FIRST100></a>
		</div></td>
	</tr></tbody></table>
	</form>
	<script type="text/javascript">with(document.postform<var $thread>) {if(!name.value) name.value=get_cookie("name"); if(!email.value) email.value=get_cookie("email"); if(!password.value) password.value=get_password("password"); }</script>

	</div>
</if></loop>

</div>

}.GLOBAL_FOOT_INCLUDE);



use constant THREAD_HEAD_TEMPLATE => compile_template( GLOBAL_HEAD_INCLUDE.q{
<body class="threadpage">

<const include("include/header.html")>

<div id="topbar">

<div id="navbar">
<strong><const S_NAVIGATION></strong>
<a href="<var $path><const HTML_SELF>"><const S_RETURN></a>
<a href="<var $self>/<var $thread>"><const S_ENTIRE></a>
<a href="<var $self>/<var $thread>/l50"><const S_LAST50></a>
<a href="<var $self>/<var $thread>/-100"><const S_FIRST100></a>
<!-- hundred links go here -->
</div>

<div id="stylebar">
<strong><const S_BOARDLOOK></strong>
<loop \@stylesheets>
	<a href="javascript:set_stylesheet('<var $title>')"><var $title></a>
</loop>
</div>

<div id="managerbar">
<strong><const S_ADMIN></strong>
<a href="javascript:set_manager()"><const S_MANAGE></a>
<span class="manage" style="display:none;">
<a href="<var $self>?task=permasagethread&thread=<var $thread>"><const S_PERMASAGETHREAD></a>
<a href="<var $self>?task=deletethread&thread=<var $thread>"><const S_DELETETHREAD></a>
</span>
</div>

</div>

<div id="posts">

<if $permasage><div class="sagethread"></if>
<if !$permasage><div class="thread"></if>
<h2><var $title> <small>(<var $postcount><if $permasage><const S_PERMASAGED></if>)</small></h2>

<div class="replies">
<div class="allreplies">
});



use constant THREAD_FOOT_TEMPLATE => compile_template( q{

</div>
</div>

<form name="postform<var $thread>" action="<var $self>" method="post">
<input type="hidden" name="task" value="post" />
<input type="hidden" name="thread" value="<var $thread>" />
<input type="hidden" name="password" value="" />
<table><tbody><tr>
	<td><nobr><const S_NAME></nobr></td>
	<td>
		<if !FORCED_ANON><input type="text" name="name" size="19" /></if>
		<if FORCED_ANON><input type="text" size="19" disabled="disabled" /><input type="hidden" name="name" /></if>
		<const S_EMAIL> <input type="text" name="email" size="19" />
		<input type="submit" value="<const S_REPLY>" />
		<if FORCED_ANON><small><const S_FORCEDANON></small></if>
	</td>
</tr><tr>
<if ENABLE_CAPTCHA>
	<td><nobr><const S_CAPTCHA></nobr></td>
	<td><input type="text" name="captcha" size="19" />
		<img class="postcaptcha" src="<var $path>captcha.pl?selector=.postcaptcha" />
	</td>
</tr><tr>
</if>
	<td></td>
	<td><textarea name="comment" cols="64" rows="5" onfocus="expand_field(<var $thread>)" onblur="shrink_field(<var $thread>)"></textarea><br /></td>
</tr></tbody></table>
</form>
<script type="text/javascript">with(document.postform<var $thread>) {if(!name.value) name.value=get_cookie("name"); if(!email.value) email.value=get_cookie("email"); if(!password.value) password.value=get_password("password"); }</script>

</div>
</div>

}.GLOBAL_FOOT_INCLUDE);



use constant THREAD_VIEW_TEMPLATE => compile_template( q{
<var $header>
<loop $replies><var $reply></loop>
<var $footer>
});



use constant REPLY_TEMPLATE => compile_template( q{

<div class="reply">

<h3>
<span class="replynum"><a title="Quote post number in reply" href="javascript:insert('&gt;&gt;<var $num>',<var $thread>)"><var $num></a></span>
<const S_POSTERNAME>
<span class="postername"><if $email><a href="mailto:<var $email>"></if><var $name><if $email></a></if></span><if $trip><span class="postertrip"><if $email><a href="mailto:<var $email>"></if><var $trip><if $email></a></if></span></if>
<var $date>
<span class="deletebutton">
<if ENABLE_DELETION>[<a href="javascript:delete_post(<var $thread>,<var $num>)"><const S_DELETE></a>]</if>
<if !ENABLE_DELETION><span class="manage" style="display:none;">[<a href="javascript:delete_post(<var $thread>,<var $num>)"><const S_DELETE></a>]</span></if>
</span>
</h3>

<div class="replytext"><var $comment></div>

</div>
});



use constant DELETED_TEMPLATE => compile_template( q{
<div class="deletedreply">
<h3>
<span class="replynum"><var $num></span>
<if $reason eq 'user'><const S_USERDELETE></if>
<if $reason eq 'mod'><const S_MODDELETE></if>
</h3>
</div>
});



use constant BACKLOG_PAGE_TEMPLATE => compile_template( GLOBAL_HEAD_INCLUDE.q{
<body class="backlogpage">

<const include("include/header.html")>

<div id="topbar">

<div id="navbar">
<strong><const S_NAVIGATION></strong>
<a href="<var $path><const HTML_SELF>"><const S_RETURN></a>
</div>

<div id="stylebar">
<strong><const S_BOARDLOOK></strong>
<loop \@stylesheets>
	<a href="javascript:set_stylesheet('<var $title>')"><var $title></a>
</loop>
</div>

<div id="managerbar">
<strong><const S_ADMIN></strong>
<a href="javascript:set_manager()"><const S_MANAGE></a>
<span class="manage" style="display:none;">
<a href="<var $self>?task=rebuild"><const S_REBUILD></a>
</span>
</div>

</div>

<div id="threads">

<h1><const TITLE></h1>

<div id="oldthreadlist">
<loop $threads>
	<span class="threadlink">
	<a href="<var $self>/<var $thread>"><var $num>. <var $title> (<var $postcount>)</a>
	<span class="manage" style="display:none;">
	( <a href="<var $self>?task=permasagethread&thread=<var $thread>"><const S_PERMASAGETHREAD></a>
	| <a href="<var $self>?task=deletethread&thread=<var $thread>"><const S_DELETETHREAD></a>
	)</span>
	</span>
</loop>
</div>

</div>

}.GLOBAL_FOOT_INCLUDE);



use constant RSS_TEMPLATE => compile_template( q{
<?xml version="1.0" encoding="<const CHARSET>"?>
<rss version="2.0">

<channel>
<title><const TITLE></title>
<link><var $absolute_path><const HTML_SELF></link>

<loop $threads><if $posts>
	<item>
	<title><var $title> (<var $postcount>)</title>
	<link><var $absolute_self>/<var $thread>/</link>
	<guid><var $absolute_self>/<var $thread>/</guid>
	<comments><var $absolute_self>/<var $thread>/</comments>
	<author><var $author></author>
	<description><![CDATA[
		<var $$posts[0]{reply}=~m!<div class="replytext".(.*?)</div!; $1 >
		<if $abbrev><p><small>Post too long, full version <a href="<var $absolute_self>/<var $thread>/">here</a>.</small></p>
		</if>
	]]></description>
	</item>
</if></loop>

</channel>
</rss>
});



use constant ERROR_TEMPLATE => compile_template( GLOBAL_HEAD_INCLUDE.q{
<body class="errorpage">

<const include("include/header.html")>

<div id="topbar">

<div id="navbar">
<strong><const S_NAVIGATION></strong>
<a href="<var escamp($ENV{HTTP_REFERER})>"><const S_RETURN></a>
</div>

<div id="stylebar">
<strong><const S_BOARDLOOK></strong>
<loop \@stylesheets>
	<a href="javascript:set_stylesheet('<var $title>')"><var $title></a>
</loop>
</div>

</div>

<h1><var $error></h1>

<h2><a href="<var escamp($ENV{HTTP_REFERER})>"><const S_RETURN></a></h2>

</body>
}.GLOBAL_FOOT_INCLUDE);


1;
